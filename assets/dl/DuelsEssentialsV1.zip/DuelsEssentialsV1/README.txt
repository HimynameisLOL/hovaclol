Cracked by cystemz, beamed by SKRRRTT

The v1.0 version of duels essentials released without a working OP bot but, the sumo, classic and boxing bot all work.
We will leak the OP bot and any future updates of duels essentials when they are released

Check out the website @ https://duelsessentials.rip/
